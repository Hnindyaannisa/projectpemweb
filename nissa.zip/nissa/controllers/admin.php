<?php

/**
 * The home page controller
 */
class Admin extends Controller
{
    private $model;

    function __construct($model)
    {
        parent::__construct();
        $this->model = $model;
        session_start();
        if (empty($_SESSION['username'])) {
            header("Location: https://userfahrul.000webhostapp.com/nissa/auth/");
        }
    }

    public function index()
    {
        return $this->render('admin/home');
    }
}
