<?php

/**
 * The home page controller
 */
class Home extends Controller
{
    private $model;

    function __construct($model)
    {
        parent::__construct();
        $this->model = $model;
    }

    public function index()
    {
        return $this->render('home');
    }
}
