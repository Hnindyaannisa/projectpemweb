<?php

/**
 * The home page controller
 */
class Auth extends Controller
{
    private $model;

    function __construct($model)
    {
        parent::__construct();
        $this->model = $model;
        session_start();
        
        if (!empty($_SESSION['username'])) {
            header("Location: https://userfahrul.000webhostapp.com/nissa/admin/");
        }
    }

    public function index()
    {
        return $this->render('login');
    }

    public function register()
    {
        return $this->render('register');
    }

    public function masuk()
    {
        if (empty($_POST)) {
            echo json_encode([
                'status' => false,
                'message' => 'Masukkan username dan password dahulu!'
            ]);
        } else {

            $result = $this->model->signin($_POST['username'], $_POST['password']);

            if (!$result) {
                echo json_encode([
                    'status' => false,
                    'message' => 'Akun belum terdaftar!'
                ]);
            } else {
                $_SESSION['username'] = $result['username'];
                $_SESSION['id'] = $result['id'];

                echo json_encode([
                    'status' => true,
                    'message' => 'Login berhasil, tunggu sebentar ...'
                ]);
            }
        }
    }

    public function requestRegister()
    {
        if (empty($_POST['username']) || empty($_POST['password'])) {
            echo json_encode([
                'status' => false,
                'message' => 'Form pendaftaran belum diisi lengkap!'
            ]);
        } else {
            $payload = [
                'username' => $_POST['username'],
                'password' => $_POST['password'],
            ];

            $result = $this->model->signup($payload);

            if (!$result) {
                echo json_encode([
                    'status' => false,
                    'message' => 'Internal server error!'
                ]);
            } else {
                echo json_encode([
                    'status' => true,
                    'message' => 'Pendaftaran berhasil, silahkan melakukan login.'
                ]);
            }
        }
    }

    public function logout()
    {
        session_destroy();
        header("Location: https://userfahrul.000webhostapp.com/nissa/home");
    }
}
