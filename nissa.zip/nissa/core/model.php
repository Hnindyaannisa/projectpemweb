<?php
class Model
{
    private $db_params = array(
        'host' => 'localhost',
        'username' => 'id13294713_fahrul123',
        'password' => 'Afr_12345678',
        'database' => 'id13294713_fahrul'
    );

    public $connection;

    function __construct()
    {
        $this->connection =  $this->tryConnect();
    }

    function tryConnect()
    {
        $conn = new mysqli(
            $this->db_params['host'],
            $this->db_params['username'],
            $this->db_params['password'],
            $this->db_params['database']
        );
        if ($conn->connect_error) {
            die("Connection Faild: " . $conn->connect_error);
        }
        return $conn;
    }
}
