<?php
class Controller
{
    function __construct()
    {
    }

    function render($view, $args = false)
    {
        if (!$args) {
            foreach ($args as $vname => $vvalue) {

                $$vname = $vvalue;
            }
        }
        require_once(__DIR__ . '/../views/' . $view . '.php');
    }
}
