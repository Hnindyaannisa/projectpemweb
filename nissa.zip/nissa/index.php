<?php
include_once __DIR__ . '/core/controller.php';
include_once __DIR__ . '/core/model.php';


$url = isset($_SERVER['PATH_INFO']) ? explode('/', ltrim($_SERVER['PATH_INFO'], '/')) : '/';

if ($url == '/') {
    try {
        require_once __DIR__ . '/models/home_model.php';
        require_once __DIR__ . '/controllers/home.php';

        $model = new HomeModel();
        $controller = new Home($model);

        return $controller->index();
    } catch (\Throwable $th) {
        die($th);
    }
} else {
    $requestedController = $url[0];

    $requestedAction = isset($url[1]) ? $url[1] : '';

    $requestedParams = array_slice($url, 2);

    $ctrlPath = __DIR__ . '/controllers/' . $requestedController . '.php';

    if (file_exists($ctrlPath)) {
        try {
            require_once __DIR__ . '/models/' . $requestedController . '_model.php';
            require_once __DIR__ . '/controllers/' . $requestedController . '.php';

            $modelName      = ucfirst($requestedController) . 'Model';
            $controllerName = ucfirst($requestedController);

            $controllerObj  = new $controllerName(new $modelName);

            if ($requestedAction != '') {
                return $controllerObj->$requestedAction($requestedParams);
            } else {
                return $controllerObj->index();
            }
        } catch (\Throwable $th) {
            die($th);
        }
    } else {
        header('HTTP/1.1 404 Not Found');
        die('404 - The file - ' . $ctrlPath . ' - not found');
    }
}
