<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>SMK TELKOM MALANG</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">
  <link href="src/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="src/css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="src/css/nice-select.css" type="text/css">
  <link rel="stylesheet" href="src/css/owl.carousel.min.css" type="text/css">
  <link rel="stylesheet" href="src/css/magnific-popup.css" type="text/css">
  <link rel="stylesheet" href="src/css/slicknav.min.css" type="text/css">
  <link rel="stylesheet" href="src/css/gaya.css" type="text/css">
  <link href="src/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="src/lib/animate/animate.min.css" rel="stylesheet">
  <link href="src/lib/venobox/venobox.css" rel="stylesheet">
  <link href="src/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="src/css/style.css" rel="stylesheet">
</head>

<body>
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#intro" class="scrollto"><img src="src/img/logotelkom.png" alt="" title=""></a>
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">PROFIL</a></li>
          <li><a href="#katalog">PROGRAM STUDI</a></li>
          <li><a href="#Pemesanan">PRESTASI</a></li>
          <li><a href="#gallery">BERITA</a></li>
          <li><a href="#footer">KONTAK KAMI</a></li>
          <li><a href="https://userfahrul.000webhostapp.com/nissa/auth">LOGIN ADMIN</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <section id="intro">
    <div class="intro-container wow fadeIn">
      <h1>The Real Informatics School<br>-- Attitude is Everything --</h1>
      <a href="#hotels" class="about-btn scrollto">v</a>
    </div>
  </section>
  <main id="main">
    <section id="hotels" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>TENTANG SMK TELKOM MALANG</h2>
          <p>SMK Telkom Malang adalah pelopor Sekolah menengah kejuruan
            pertama di Indonesia di bidang Teknologi dan Informatika.
            Berpengalaman dari tahun 1992 yang telah terakreditasi "A"
            dan mempunyai standart mutu ISO 9001:2015.</p>
        </div>

      </div>

      <div class="row">
        <img src="src/img/smk telkom.jpg" width="50%" height="50%" style="display: block; margin: auto;">
      </div>
    </section>
    <br>

    <section id="katalog" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>PROGRAM STUDI</h2>
          <p>Kami mempunyai dua program studi unggulan yang banyak dicari oleh industri-industri di dunia IT. </p>
        </div>
        <div class="row">
          <div class="col-lg-6 col-md-12">
            <div class="speaker">
              <img src="src/img/prodi.png" alt="Speaker 1" class="img-fluid">
              <div class="details">
                <h3><a href="K1.html">Rekaya Perangkat Lunak</a></h3>
                <p>Mempelajari seluruh aspek produksi software seperti aplikasi website, aplikasi android, maupun
                  aplikasi dekstop</p>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12">
            <div class="speaker">
              <img src="src/img/prodi1.png" alt="Speaker 2" class="img-fluid">
              <div class="details">
                <h3><a href="K2.html">Teknik Komputer dan Jaringan</a></h3>
                <p>Memepelajari cara merakit dan instalasi komputer, instalasi jaringan, Local Area Network (LAN) dan
                  Wide Area Network(WAN)</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <br>
    <br>
    <br>
    <section id="Pemesanan" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>PRESTASI KAMI</h2>
          <p>Banyak kompetisi di bidang IT maupun non-IT yang banyak diraih oleh siswa-siswi SMK Telkom Malang. Segala
            prestasi tersebut
            sangat membanggakan sekolah dan dapat menjadi bekal untuk meraih masa depan yang gemilang. </p>
        </div>

        <div class="row">
          <div class="col-lg-6 col-md-12">
            <div class="speaker">
              <img src="src/img/juara.jpg" alt="Speaker 1" class="img-fluid">
              <div class="details">
                <h4>EDUNATION ITTS LINE FOLLOWER COMPETITION</h4>

              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12">
            <div class="speaker">
              <img src="src/img/juara1.jpg" alt="Speaker 2" class="img-fluid">
              <div class="details">
                <h4>Perjalanan Meraih Juara 2 Olimpiade Mikrotik 2018</h4>

              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
  </main>
  <section id="gallery" class="wow fadeInUp">

    <div class="container">
      <div class="section-header">
        <h2>INFO TERBARU</h2>
        <p>Ikuti terus informasi dan berita-berita terbaru tentang SMK Telkom Malang.</p>
      </div>
    </div>

    <div class="owl-carousel gallery-carousel">
      <a href="src/img/prs/a1.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a1.jpg" alt=""></a>
      <a href="src/img/prs/a2.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a2.jpg" alt=""></a>
      <a href="src/img/prs/a3.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a3.jpg" alt=""></a>
      <a href="src/img/prs/a4.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a4.jpg" alt=""></a>
      <a href="src/img/prs/a5.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a5.jpg" alt=""></a>
      <a href="src/img/prs/a6.png" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a6.png" alt=""></a>
      <a href="src/img/prs/a7.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a7.jpg" alt=""></a>
      <a href="src/img/prs/a8.jpg" class="venobox" data-gall="gallery-carousel"><img src="src/img/prs/a8.jpg" alt=""></a>
    </div>

  </section>
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <p>Pelopor SMK bidang Teknologi dan Informatika
              di Indonesia. Berpengalaman dari tahun 1992 yang
              telah terakreditasi "A" dan mempunyai standart mutu
              ISO 9001:2015.</p>
          </div>
          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Hubungi Kami</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Twitter</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Facebook</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Instagram</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Google Plus</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Linkedin</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Jl. Danau Ranau Sawojajar<br>
              Kota Malang<br>
              <strong>Phone:</strong> 0341-712500<br>
              <strong>Email:</strong> info@smktelkom-mlg.sch.id<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <img src="src/img/logo-moklet.png" alt="TheEvenet">
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright 2020 <strong>SMK Telkom Malang</strong>. All Rights Reserved
      </div>
      <div class="credits">
      </div>
    </div>
  </footer>

  <a href="home" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <script src="src/lib/jquery/jquery.min.js"></script>
  <script src="src/lib/jquery/jquery-migrate.min.js"></script>
  <script src="src/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="src/lib/easing/easing.min.js"></script>
  <script src="src/lib/superfish/hoverIntent.js"></script>
  <script src="src/lib/superfish/superfish.min.js"></script>
  <script src="src/lib/wow/wow.min.js"></script>
  <script src="src/lib/venobox/venobox.min.js"></script>
  <script src="src/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="src/contactform/contactform.js"></script>
  <script src="src/js/main.js"></script>
</body>

</html>