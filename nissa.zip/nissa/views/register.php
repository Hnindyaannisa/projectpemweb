<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Register - Dashboard SMK Telkom</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.4/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com//docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- Favicons -->
    <link rel="icon" href="https://getbootstrap.com//docs/4.4/assets/img/favicons/favicon.ico">
    <meta name="msapplication-config" content="https://getbootstrap.com//docs/4.4/assets/img/favicons/browserconfig.xml">
    <meta name="theme-color" content="#563d7c">

    <style>
        .form-signin .form-control {
            position: relative;
            box-sizing: border-box;
            height: auto;
            padding: 10px;
            font-size: 16px;
        }

        .form-signin .form-control:focus {
            z-index: 2;
        }

        .form-signin input[type="text"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }

        .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }
    </style>
</head>

<body background="https://1.bp.blogspot.com/-CIz9HPNY8XM/XrJfo_Wl6oI/AAAAAAAAIoI/tYQdUJLAp4cyFGPhlABkxN_O9S5L_e6zgCLcBGAsYHQ/s1600/8.png">
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Dashboard SMK Telkom</h5>
        <?php if ($_SESSION['user']) : ?>
            <nav class="my-2 my-md-0 mr-md-3">
                <a class="p-2 text-dark" href="#">Home</a>
                <a class="p-2">Hi, <?= $_SESSION['user'] ? $_SESSION['user'] : "Guest"; ?></a>
                <a href="https://userfahrul.000webhostapp.com/nissa/auth/logout" class="btn btn-outline-primary">Logout</a>
            </nav>
        <?php else : ?>
            <nav class="my-2 my-md-0 mr-md-3">
                <a href="https://userfahrul.000webhostapp.com/nissa/auth/register" class="btn btn-outline-danger">Register</a>
                <a href="https://userfahrul.000webhostapp.com/nissa/auth/" class="btn btn-danger">Login</a>
            </nav>

        <?php endif; ?>
    </div>

    <div class="container">
        <div class="row mx-auto text-center pt-5 mt-5">
            <div class="col-md-12">
                <h1 class="display-4">Register</h1>
                <p class="lead">Isi data dirimu untuk mendaftar.</p>
            </div>
            <div class="offset-3 col-md-6">
                <div class="alert alert-danger" style="display: none"></div>
                <div class="alert alert-success" style="display: none"></div>
                <form class="form-signin mt-5" id="form-login">
                    <label class="sr-only">Username</label>
                    <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
                    <label class="sr-only">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">

                    <button class="btn btn-lg btn-primary btn-block mt-5" type="submit">Daftar</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <script>
        $('#form-login').on('submit', (e) => {
            e.preventDefault();
            $('.alert-success').hide();
            $('.alert-danger').hide();

            $.ajax({
                type: "POST",
                url: "https://userfahrul.000webhostapp.com/nissa/auth/requestRegister",
                data: $("#form-login :input").serialize(),
                dataType: "json",
                success: function(response) {
                    if (!response.status) {
                        $('.alert-danger').html(response.message);
                        $('.alert-danger').show();
                    } else {
                        $('.alert-success').html(response.message);
                        $('.alert-success').show();

                        setTimeout(() => {
                            window.location.replace('https://userfahrul.000webhostapp.com/nissa/auth/');
                        }, 2000);
                    }
                }
            });
        })
    </script>
</body>

</html>