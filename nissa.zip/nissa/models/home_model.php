<?php

/**
 * The home page model
 */
class HomeModel extends Model
{

    function __construct()
    {
        parent::__construct();
    }
}
