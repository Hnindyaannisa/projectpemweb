<?php

/**
 * The home page model
 */
class AuthModel extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function signin($username, $password)
    {
        $query = "SELECT * FROM pengguna WHERE username = '$username' AND password = '$password'";
        $result = $this->connection->query($query);
        if ($query->num_rows === 0) {
            return false;
        } else {
            return $result->fetch_assoc();
        }
    }

    public function signup($data)
    {
        $query = "INSERT INTO pengguna (`username`, `password`) VALUES('" . $data['username'] . "', '" . $data['password'] . "')";
        $result = $this->connection->query($query);
        if (!$result) {
            return false;
        } else {
            return true;
        }
    }
}
