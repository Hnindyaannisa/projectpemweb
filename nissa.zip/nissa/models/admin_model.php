<?php

/**
 * The home page model
 */
class AdminModel extends Model
{

    function __construct()
    {
        parent::__construct();
    }
}
